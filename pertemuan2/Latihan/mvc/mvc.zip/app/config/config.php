<?php

define("BASEURL", "http://localhost/belajar/phpmvc/sesi13/public");

// DATANASE
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'php_mvc');
