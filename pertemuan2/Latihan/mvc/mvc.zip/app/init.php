<?php

// inisasi

// Core adalah classnya
require_once 'core/App.php';
// controler ini utama, controllers extend
require_once 'core/Controller.php';
// database
require_once 'core/Database.php';
// KOnstanta
require_once 'config/config.php';
// Flasher
require_once 'core/Flasher.php';
